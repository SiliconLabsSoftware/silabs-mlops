"""
SiLabs MLOps Data Module (AI Reviewed Version)

Improvements:
- Uses logging instead of print.
- Removed global sync with central Config to prevent side-effects.
- Added type hints and cleaner error propagation.
"""

import logging
from typing import List, Dict, Any, Optional

from .ingest import IngestConfig, DataIngestor

logger = logging.getLogger(__name__)

# Module-level configuration storage
_config: Optional[IngestConfig] = None

__all__ = [
    "config",
    "ingest",
    "ingest_from_file",
]


def config(
    server_endpoint: str,
    workspace_url: str,
    table_name: str,
    client_id: str,
    client_secret: str
) -> None:
    """
    Configure your Databricks credentials for data ingestion.
    Better validation and logging.
    """
    global _config
    _config = IngestConfig(
        server_endpoint=server_endpoint,
        workspace_url=workspace_url,
        table_name=table_name,
        client_id=client_id,
        client_secret=client_secret
    )
    
    logger.info("Data ingestion configuration updated successfully.")


def ingest(data: List[Dict[str, Any]]) -> bool:
    """
    Ingest data with proper error logging.
    """
    if _config is None:
        logger.error("Configuration not set. Call data.config() first.")
        return False
    
    try:
        with DataIngestor(_config) as ingestor:
            return ingestor.ingest(data=data)
    except Exception as e:
        logger.exception(f"Unexpected error in data.ingest: {e}")
        return False


def ingest_from_file(file_path: str) -> bool:
    """
    Ingest from file with proper error logging.
    """
    if _config is None:
        logger.error("Configuration not set. Call data.config() first.")
        return False
    
    try:
        with DataIngestor(_config) as ingestor:
            return ingestor.ingest(buffer_path=file_path)
    except Exception as e:
        logger.exception(f"Unexpected error in data.ingest_from_file: {e}")
        return False
