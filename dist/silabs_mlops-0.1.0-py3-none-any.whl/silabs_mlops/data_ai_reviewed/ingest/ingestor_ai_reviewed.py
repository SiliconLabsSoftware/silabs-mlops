"""
Data ingestion orchestrator for ZeroBus (AI Reviewed Version).
Includes context manager support and better error propagation.
"""

import json
import logging
import traceback
from pathlib import Path
from typing import List, Dict, Any, Optional

from .config import IngestConfig
from .zerobus_client import ZerobusIngestClient

logger = logging.getLogger(__name__)


class DataIngestor:
    """
    Orchestrates data ingestion with safe resource cleanup via context manager.
    """

    def __init__(self, config: IngestConfig):
        self.config = config
        self.client = ZerobusIngestClient(
            server_endpoint=config.server_endpoint,
            workspace_url=config.workspace_url,
            table_name=config.table_name,
            client_id=config.client_id,
            client_secret=config.client_secret,
        )

    def __enter__(self):
        """Automatically establish connection when using 'with' statement."""
        self.client.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Automatically close connection on exit, even if an error occurred."""
        self.client.close()

    def _read_buffered_records(self, buffer_path: Optional[str] = None) -> List[Dict[str, Any]]:
        """Safely reads records from a file with improved JSON parsing."""
        path = buffer_path or self.config.buffer_path
        if not path:
            return []

        buffer_file = Path(path)
        if not buffer_file.exists():
            logger.warning(f"Buffer file not found at {path}")
            return []

        records = []
        try:
            with open(buffer_file, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    return []
                
                # Dynamic format detection
                try:
                    loaded = json.loads(content)
                    if isinstance(loaded, list):
                        return loaded
                    return [loaded]
                except json.JSONDecodeError:
                    # Fallback to JSON Lines
                    for line in content.split('\n'):
                        line = line.strip()
                        if line:
                            try:
                                records.append(json.loads(line))
                            except json.JSONDecodeError:
                                logger.error(f"Malforming line skipped: {line[:50]}...")
        except IOError as e:
            logger.error(f"Failed to read file {path}: {e}")
            
        return records

    def ingest(self, data: Optional[List[Dict[str, Any]]] = None, buffer_path: Optional[str] = None) -> bool:
        """Processes ingestion batch with improved error logging."""
        records = data if data is not None else self._read_buffered_records(buffer_path)

        if not records:
            logger.warning("No records identified for ingestion.")
            return False

        logger.info(f"Ingesting {len(records)} records to {self.config.table_name}")

        try:
            # Note: Sequential ingestion is inefficient. 
            # Future improvement: Use Parallel workers for large batches.
            self.client.ingest_batch(records)
            logger.info("Batch ingestion completed successfully.")
            return True
        except Exception as e:
            err_msg = str(e)
            if "401" in err_msg or "Unauthorized" in err_msg:
                logger.error(f"Authentication failure (401) for table {self.config.table_name}. Check Service Principal credentials.")
            elif "4044" in err_msg or "Schema" in err_msg:
                logger.error(f"Schema mismatch (4044) for table {self.config.table_name}. Ensure data keys match Delta columns.")
            else:
                logger.exception(f"Unexpected error during batch ingestion: {e}")
            return False
