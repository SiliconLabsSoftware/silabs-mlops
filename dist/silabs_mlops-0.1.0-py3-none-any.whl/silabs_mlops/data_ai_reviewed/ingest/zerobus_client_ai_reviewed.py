"""
ZeroBus client wrapper (AI Reviewed Version).
Includes safer connection tracking and removal of redundant prints.
"""
from typing import Dict, Any, List, Optional, Callable
import logging

try:
    from zerobus.sdk.sync import ZerobusSdk
    from zerobus.sdk.shared import RecordType, StreamConfigurationOptions, TableProperties
    ZEROBUS_AVAILABLE = True
except ImportError:
    ZEROBUS_AVAILABLE = False

logger = logging.getLogger(__name__)


class ZerobusIngestClient:
    """
    Cleaner interface for ZeroBus SDK ingestion.
    """

    def __init__(
        self,
        server_endpoint: str,
        workspace_url: str,
        table_name: str,
        client_id: str,
        client_secret: str,
        ack_callback: Optional[Callable[[Any], None]] = None,
    ):
        if not ZEROBUS_AVAILABLE:
            raise ImportError(
                "databricks-zerobus-ingest-sdk is not installed. "
                "Install it with: pip install databricks-zerobus-ingest-sdk"
            )
        
        self.server_endpoint = server_endpoint
        self.workspace_url = workspace_url
        self.table_name = table_name
        self.client_id = client_id
        self.client_secret = client_secret
        self.ack_callback = ack_callback

        self._sdk = None
        self._stream = None

    def connect(self) -> None:
        """Initialize ZeroBus stream connection."""
        try:
            self._sdk = ZerobusSdk(self.server_endpoint, self.workspace_url)
            table_properties = TableProperties(self.table_name)
            
            options = StreamConfigurationOptions(
                record_type=RecordType.JSON,
                ack_callback=self.ack_callback if self.ack_callback else None
            )

            self._stream = self._sdk.create_stream(
                self.client_id,
                self.client_secret,
                table_properties,
                options,
            )
            logger.info(f"Connected to ZeroBus stream for table: {self.table_name}")
        except Exception as e:
            logger.error(f"Failed to connect to table {self.table_name}: {e}")
            raise e

    def ingest_record(self, record: Dict[str, Any], wait_for_ack: bool = True) -> None:
        """Performs a single record ingestion."""
        if not self._stream:
            raise RuntimeError("ZeroBus stream not initialized. Call connect() first.")

        ack = self._stream.ingest_record(record)
        if wait_for_ack:
            ack.wait_for_ack()

    def ingest_batch(self, records: List[Dict[str, Any]], wait_for_ack: bool = True) -> None:
        """Iteratively ingests records."""
        for record in records:
            self.ingest_record(record, wait_for_ack=wait_for_ack)

    def close(self) -> None:
        """Close ZeroBus stream safely."""
        if self._stream:
            try:
                self._stream.close()
                logger.debug(f"Closed ZeroBus stream for table: {self.table_name}")
            except Exception as e:
                logger.warning(f"Error during stream close: {e}")
            finally:
                self._stream = None
