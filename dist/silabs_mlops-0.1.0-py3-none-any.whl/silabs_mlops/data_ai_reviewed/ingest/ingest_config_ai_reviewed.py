"""
Configuration for ZeroBus ingestion (AI Reviewed Version).
Includes improved field sanitization and validation.
"""

from dataclasses import dataclass, fields
from typing import Optional


@dataclass
class IngestConfig:
    """
    Configuration for ingesting data to Databricks via ZeroBus.
    
    Now includes a cleaner version of the whitespace stripping logic.
    """
    server_endpoint: str
    workspace_url: str
    table_name: str
    client_id: str
    client_secret: str
    buffer_path: Optional[str] = None

    def __post_init__(self):
        """Sanitize all string fields consistently."""
        # Automate stripping of whitespace for all string attributes
        for field in fields(self):
            attr_name = field.name
            attr_val = getattr(self, attr_name)
            if isinstance(attr_val, str):
                setattr(self, attr_name, attr_val.strip())
        
        # Specific sanitation for URLs
        if self.workspace_url:
            self.workspace_url = self.workspace_url.rstrip("/")
            
        # Basic field validation
        if not self.server_endpoint or "." not in self.server_endpoint:
            raise ValueError(f"Invalid server_endpoint: {self.server_endpoint}")
            
        if not self.workspace_url.startswith(("http://", "https://")):
            raise ValueError(f"workspace_url must start with http/https: {self.workspace_url}")
            
        if self.table_name.count('.') < 2:
            # Expected catalog.schema.table format
            pass
            # We don't raise error but we could warn
