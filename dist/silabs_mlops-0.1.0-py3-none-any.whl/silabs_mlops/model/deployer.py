"""
Raspberry Pi Firmware Deployer.
Uploads a firmware file to a Raspberry Pi and flashes it to a Silabs board.
"""

import subprocess
import logging
import re
import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
logger = logging.getLogger(__name__)


class RPiDeployer:
    """
    Deploy and flash firmware to a Silabs device connected to a Raspberry Pi.
    - Uploads firmware using SCP
    - Runs Commander on the Raspberry Pi using SSH
    - Auto-detects J-Link serial and MCU part number (via "Part Number : ...")
    """

    def __init__(self, rpi_host: str, rpi_user: str, local_file_path: str, commander_path: str, jlink_serial: str = None):
        self.rpi_host = rpi_host
        self.rpi_user = rpi_user
        self.local_file_path = local_file_path
        self.commander_path = commander_path  # Default/Fallback path
        self.resolved_commander = commander_path # Updated during discovery
        self.jlink_serial = jlink_serial

        if not os.path.exists(self.local_file_path):
            raise FileNotFoundError(f"Local firmware file not found: {self.local_file_path}")

    # ----------------------------------------------------------
    def deploy(self, jlink_serial: str = None):
        remote_path = f"/tmp/{os.path.basename(self.local_file_path)}"
        ssh_target = f"{self.rpi_user}@{self.rpi_host}"

        logger.info(f"Targeting remote Raspberry Pi: {ssh_target}")
        print("Connected to Raspberry Pi")

        # 0. Smart Discovery: Find Commander on the remote Pi
        self.resolved_commander = self._find_remote_commander(ssh_target)

        # 1. Upload firmware
        self._scp_firmware(self.local_file_path, ssh_target, remote_path)
        print("Firmware uploaded")

        # 2. Select J-Link serial (Interactive if not provided)
        serial_to_use = jlink_serial or self.jlink_serial
        if not serial_to_use:
            serials = self._get_jlink_serials(ssh_target)
            if not serials:
                raise RuntimeError("No J-Link devices connected to the Raspberry Pi.")
            
            if len(serials) == 1:
                serial_to_use = serials[0]
                print(f"Auto-selected only connected device: {serial_to_use}")
            else:
                print("\nMultiple devices detected. Please select one:")
                for i, s in enumerate(serials, 1):
                    print(f"{i}) J-Link Serial: {s}")
                
                choice = input(f"\nSelect board [1-{len(serials)}]: ").strip()
                try:
                    idx = int(choice) - 1
                    if 0 <= idx < len(serials):
                        serial_to_use = serials[idx]
                    else:
                        raise ValueError()
                except ValueError:
                    raise RuntimeError("Invalid selection. Aborting.")

        # 3. Detect device part number from device info
        device_name = self._get_device_name(ssh_target, serial_to_use)

        # 4. Flash firmware
        self._flash_firmware(ssh_target, remote_path, serial_to_use, device_name)

    def _find_remote_commander(self, ssh_target: str) -> str:
        """
        Attempts to automatically locate the Simplicity Commander executable on the Pi.
        Checks: PATH, Desktop, and Home directory.
        """
        # Search commands for standard names and the specific user path found
        search_snippet = (
            "which commander || "
            "which commander-cli || "
            "find /home/$USER/Desktop -maxdepth 3 -name commander-cli -executable -type f 2>/dev/null | head -n 1 || "
            "find /home/$USER/Desktop -maxdepth 3 -name commander -executable -type f 2>/dev/null | head -n 1 || "
            "find /home/$USER -maxdepth 2 -name commander -executable -type f 2>/dev/null | head -n 1"
        )
        
        cmd = ["ssh", ssh_target, search_snippet]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        
        resolved = result.stdout.strip()
        if resolved:
            logger.info(f"Auto-detected commander at: {resolved}")
            return resolved
            
        # Fallback to the provided path if discovery fails
        logger.warning(f"Could not auto-detect commander. Falling back to: {self.commander_path}")
        return self.commander_path

    # ----------------------------------------------------------
    def _scp_firmware(self, local: str, ssh_target: str, remote: str):
        # Added resilience for unstable networks: 30s timeout and 5 attempts
        cmd = [
            "scp", 
            "-o", "ConnectTimeout=30", 
            "-o", "ConnectionAttempts=5",
            local, f"{ssh_target}:{remote}"
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        if result.returncode != 0:
            raise RuntimeError(f"SCP failed (check network/IP):\n{result.stderr}")

    # ----------------------------------------------------------
    def _get_jlink_serials(self, ssh_target: str) -> list:
        """
        Run `commander adapter list` and extract all serial numbers.
        """
        cmd = [
            "ssh", 
            "-o", "ConnectTimeout=30", 
            "-o", "ConnectionAttempts=5",
            ssh_target,
            f"{self.resolved_commander} adapter list"
        ]

        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        if result.returncode != 0:
            raise RuntimeError(f"Adapter list failed:\n{result.stderr}")

        serials = re.findall(r"serialNumber\s*=\s*(\d+)", result.stdout)
        return serials

    # ----------------------------------------------------------
    def _get_device_name(self, ssh_target: str, jlink_serial: str) -> str:
        """
        Run:
            commander device info --serialno <SN>

        Extract device name from:
            Part Number : EFR32MG26B510F3200IM68
        """
        cmd = [
            "ssh", 
            "-o", "ConnectTimeout=30", 
            "-o", "ConnectionAttempts=5",
            ssh_target,
            f"{self.resolved_commander} device info --serialno {jlink_serial}"
        ]

        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        print("Device info:")
        print(result.stdout)

        if result.returncode != 0:
            raise RuntimeError(f"Device info failed:\n{result.stderr}")

        # Extract chip from: Part Number : EFR32MG26B510F3200IM68
        m = re.search(r"Part Number\s*:\s*([A-Za-z0-9_]+)", result.stdout)
        if not m:
            raise RuntimeError("Could not extract device name from Commander output.")

        device_name = m.group(1).strip()
        print("Detected Device Name:", device_name)
        return device_name

    # ----------------------------------------------------------
    def _flash_firmware(self, ssh_target: str, remote_path: str, jlink_serial: str, device_name: str):
        """
        Correct flash syntax:
            commander flash <file> --serialno <SN> --device <PART> -v
        """
        cmd = [
            "ssh", 
            "-o", "ConnectTimeout=30", 
            "-o", "ConnectionAttempts=5",
            ssh_target,
            f"{self.resolved_commander} flash \"{remote_path}\" "
            f"--serialno {jlink_serial} "
            f"--device {device_name} -v"
        ]

        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        print("Flash Output:")
        print(result.stdout)

        if result.returncode != 0:
            print("Flash Errors:\n", result.stderr)
            raise RuntimeError("Flash failed.")