"""
silabs_mlops.model (AI Reviewed Version)
Unified public API for deployment and profiling.
"""

from typing import Optional, Any

from .config import DeployConfig
from .deployer import RPiDeployer
from .profiler import NPUProfiler, ProfileResult, LayerProfile

# Singleton profiler instance used by the package-level `profile()` helper.
_profiler = NPUProfiler()


def deploy(
    model_path: str,
    rpi_host: str,
    rpi_user: str = "pi",
    commander_path: str = "commander",
    jlink_serial: Optional[str] = None
) -> None:
    """
    Convenience helper to deploy a firmware file to a Silicon Labs device
    connected to a Raspberry Pi. Matches the `profile()` function's signature.
    
    Args:
        model_path:     Local path to the .s37, .bin, or .hex firmware file.
        rpi_host:       IP address or hostname of the target Raspberry Pi.
        rpi_user:       Username for SSH/SCP connection (default "pi").
        commander_path: Fallback path to Simplicity Commander on the Pi.
        jlink_serial:   Optional J-Link serial number for targeted flashing.
    """
    deployer = RPiDeployer(
        rpi_host=rpi_host,
        rpi_user=rpi_user,
        local_file_path=model_path,
        commander_path=commander_path,
        jlink_serial=jlink_serial
    )
    return deployer.deploy()


def profile(
    model_path: str,
    device_id: Optional[str] = None,
    output_dir: Optional[str] = None,
    profiler_path: Optional[str] = None,
    gui: bool = False,
    timeout: int = 600,
    accelerator: str = "mvpv1",
    platform: Optional[str] = None,
    weights_paging: bool = False,
    use_simulator: bool = False,
    volume_path: Optional[str] = None
) -> ProfileResult:
    """
    Profile a model using the Silicon Labs NPU Toolkit (mvp_profiler).
    """
    return _profiler.profile(
        model_path, device_id, output_dir, profiler_path, gui,
        timeout, accelerator, platform, weights_paging, use_simulator,
        volume_path
    )


__all__ = [
    # Deployment
    "DeployConfig",
    "RPiDeployer",
    "deploy",
    # Profiler
    "NPUProfiler",
    "ProfileResult",
    "LayerProfile",
    "profile",
]
