"""
Raspberry Pi Firmware Deployer (AI Reviewed Version).
Includes improved security, timeouts, and non-interactive automation support.
"""

import subprocess
import logging
import re
import os
import sys
import shlex
from typing import Optional, List

logger = logging.getLogger(__name__)


class RPiDeployer:
    """
    Orchestrates firmware deployment to a Silicon Labs device connected to a Raspberry Pi.
    
    Improvements:
    - Added timeouts to all subprocess calls.
    - Replaced prints with logging.
    - Added non-interactive protection for board selection.
    - Sanitized remote commands with shlex.quote.
    """

    def __init__(
        self, 
        rpi_host: str, 
        rpi_user: str, 
        local_file_path: str, 
        commander_path: str, 
        jlink_serial: Optional[str] = None,
        timeout: int = 60
    ):
        self.rpi_host = rpi_host
        self.rpi_user = rpi_user
        self.local_file_path = local_file_path
        self.commander_path = commander_path
        self.resolved_commander = commander_path
        self.jlink_serial = jlink_serial
        self.base_timeout = timeout

        if not os.path.exists(self.local_file_path):
            raise FileNotFoundError(f"[Validation Error] Local firmware file not found: {self.local_file_path}")

        # Set environment optimization only if not already set, to avoid overriding user preferences
        if 'TF_ENABLE_ONEDNN_OPTS' not in os.environ:
            os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

    def deploy(self, jlink_serial: Optional[str] = None):
        """
        Full deployment sequence.
        
        Args:
            jlink_serial: Optional override for the target device's serial number.
        """
        remote_path = f"/tmp/silabs_fw_{os.path.basename(self.local_file_path)}"
        ssh_target = f"{self.rpi_user}@{self.rpi_host}"

        logger.info(f"Connecting to Raspberry Pi: {ssh_target}")

        # 1. Discover Commander on remote
        self.resolved_commander = self._find_remote_commander(ssh_target)

        # 2. Upload firmware
        self._scp_firmware(self.local_file_path, ssh_target, remote_path)
        logger.info("Firmware uploaded to remote /tmp/")

        # 3. Select Serial
        serial_to_use = jlink_serial or self.jlink_serial
        if not serial_to_use:
            serial_to_use = self._select_serial_interactive(ssh_target)

        # 4. Detect Part
        device_name = self._get_device_name(ssh_target, serial_to_use)

        # 5. Flash
        self._flash_firmware(ssh_target, remote_path, serial_to_use, device_name)
        logger.info("Deployment successful.")

    def _find_remote_commander(self, ssh_target: str) -> str:
        """Locates commander binary on the Pi safely."""
        search_snippet = (
            "which commander || which commander-cli || "
            "find /home/$USER/Desktop -maxdepth 3 -name commander-cli -executable -type f 2>/dev/null | head -n 1"
        )
        
        try:
            cmd = ["ssh", ssh_target, search_snippet]
            result = subprocess.run(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE, 
                text=True, 
                timeout=self.base_timeout
            )
            
            resolved = result.stdout.strip()
            if resolved:
                logger.debug(f"Auto-detected commander at: {resolved}")
                return resolved
        except subprocess.TimeoutExpired:
            logger.warning("Commander discovery timed out. Using fallback path.")
        except Exception as e:
            logger.debug(f"Discovery error: {e}")

        return self.commander_path

    def _scp_firmware(self, local: str, ssh_target: str, remote: str):
        """Uploads file with resilience flags."""
        cmd = [
            "scp", 
            "-o", "ConnectTimeout=15", 
            "-o", "ConnectionAttempts=3",
            local, f"{ssh_target}:{remote}"
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=120)  # Larger timeout for upload
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"SCP failed: {e.stderr.decode().strip() or 'Check network connectivity.'}")
        except subprocess.TimeoutExpired:
            raise RuntimeError("SCP upload timed out. The file might be too large or the network too slow.")

    def _get_jlink_serials(self, ssh_target: str) -> List[str]:
        """Lists connected adapters via SSH."""
        # Using shlex.quote for the remote command part
        remote_cmd = f"{shlex.quote(self.resolved_commander)} adapter list"
        cmd = ["ssh", ssh_target, remote_cmd]
        
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=self.base_timeout)
            serials = re.findall(r"serialNumber\s*=\s*(\d+)", result.stdout)
            return serials
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to list adapters: {e.stderr.strip()}")

    def _select_serial_interactive(self, ssh_target: str) -> str:
        """Handles serial selection with a fallback for non-interactive environments."""
        serials = self._get_jlink_serials(ssh_target)
        if not serials:
            raise RuntimeError("No J-Link devices detected on the Raspberry Pi.")
        
        if len(serials) == 1:
            logger.info(f"Auto-selecting only device: {serials[0]}")
            return serials[0]

        # Automation check: Fail if we can't ask the user
        if not sys.stdin.isatty():
            raise RuntimeError(
                f"Multiple devices found ({serials}) but terminal is non-interactive. "
                "Please specify jlink_serial explicitly."
            )

        print("\nMultiple SiLabs boards detected:")
        for i, s in enumerate(serials, 1):
            print(f"  {i}) Serial: {s}")
        
        try:
            choice = input(f"\nSelect board [1-{len(serials)}]: ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(serials):
                return serials[idx]
        except (ValueError, EOFError):
            pass
        
        raise RuntimeError("Invalid selection or input interrupted.")

    def _get_device_name(self, ssh_target: str, jlink_serial: str) -> str:
        """Retrieves hardware part number safely."""
        remote_cmd = f"{shlex.quote(self.resolved_commander)} device info --serialno {shlex.quote(jlink_serial)}"
        cmd = ["ssh", ssh_target, remote_cmd]
        
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=self.base_timeout)
            m = re.search(r"Part Number\s*:\s*([A-Za-z0-9_]+)", result.stdout)
            if not m:
                raise RuntimeError("Commander succeeded but 'Part Number' was missing from output.")
            
            part = m.group(1).strip()
            logger.info(f"Detected target hardware: {part}")
            return part
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Device info failed for SN {jlink_serial}: {e.stderr.strip()}")

    def _flash_firmware(self, ssh_target: str, remote_path: str, jlink_serial: str, device_name: str):
        """Executes the flash command on the Pi."""
        # Carefully quote all remote parameters
        remote_cmd = (
            f"{shlex.quote(self.resolved_commander)} flash {shlex.quote(remote_path)} "
            f"--serialno {shlex.quote(jlink_serial)} "
            f"--device {shlex.quote(device_name)} -v"
        )
        cmd = ["ssh", ssh_target, remote_cmd]
        
        logger.info("Flashing firmware...")
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=300) # Flashing can take time
        except subprocess.CalledProcessError as e:
            logger.error(f"Commander Flash Error:\n{e.stderr}")
            raise RuntimeError("Flash failed. Check device connection and firmware compatibility.")
        except subprocess.TimeoutExpired:
            raise RuntimeError("Flash command timed out. Ensure Simplicity Commander is responsive on the Pi.")
