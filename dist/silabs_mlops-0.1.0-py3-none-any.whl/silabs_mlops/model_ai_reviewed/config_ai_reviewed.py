"""
Configuration for Model Deployment (AI Reviewed Version).
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class DeployConfig:
    """
    Unified configuration for Silicon Labs model deployment.
    
    Now includes validation and RPi-specific defaults.
    """
    # Source
    model_uri: str
    
    # RPi Target (Required for RPiDeployer)
    rpi_host: Optional[str] = None
    rpi_user: str = "pi"
    
    # Flash Settings
    commander_path: str = "commander"
    jlink_serial: Optional[str] = None
    
    # Advanced Flash Options
    verify: bool = True
    halt: bool = False
    
    def __post_init__(self):
        """Sanity check on initialization."""
        if not self.model_uri:
            raise ValueError("model_uri must be provided (local path or MLflow URI).")
        
        # If an RPi host is given, ensure it's a valid non-empty string
        if self.rpi_host == "":
            self.rpi_host = None
