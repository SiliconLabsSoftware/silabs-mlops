"""
SiLabs Volume + ZeroBus Audio Simulator (spoken GSC-style words, multi-device)

Split ingestion:
  • Raw WAV -> Databricks Unity Catalog Volume (Files API)
  • Metadata -> Delta via ZeroBus (silabs_mlops.data)

"""

import os
import sys
import logging
import io
import time
import uuid
import base64
import random
import argparse
import requests
import subprocess
import numpy as np
import soundfile as sf
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from scipy.signal import resample, resample_poly, fftconvolve

# -----------------------------
# Aggressive Log Suppression
# -----------------------------
# This must happen before any other imports
for logger_name in ["databricks_zerobus_ingest_sdk", "silabs_mlops", "urllib3", "requests"]:
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.ERROR)
    logger.propagate = False

# Silence root logger as a fallback
logging.getLogger().setLevel(logging.WARNING)

# -----------------------------
# Environment Flags
# -----------------------------
# Some native SDKs use env vars for logging
os.environ["RUST_LOG"] = "error"
os.environ["ZEROBUS_LOG_LEVEL"] = "error"

# -------------------------
# Optional .env loader
# -------------------------
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# -------------------------
# ZeroBus SDK (optional)
# -------------------------
try:
    from silabs_mlops import data as zerobus_data
    ZEROBUS_AVAILABLE = True
except Exception:
    ZEROBUS_AVAILABLE = False
    print("[warn] ZeroBus SDK not found; metadata ingestion disabled.", file=sys.stderr)

# -------------------------
# gTTS (online TTS) for real speech
# -------------------------
try:
    from gtts import gTTS
    GTTS_AVAILABLE = True
except ImportError as e:
    GTTS_AVAILABLE = False
    print(f"[ERROR] gTTS not available: {e}. Install with: pip install gTTS", file=sys.stderr)
except Exception as e:
    GTTS_AVAILABLE = False
    print(f"[ERROR] gTTS loading failed: {e}", file=sys.stderr)

# -------------------------
# Audio defaults
# -------------------------
SAMPLE_RATE = int(os.getenv("SIM_SAMPLE_RATE", "16000"))
DURATION_MS = int(os.getenv("SIM_DURATION_MS", "1000"))

# Expanded GSC-like label set (your original list)
DEFAULT_LABELS = [
    "left","right","on","off","stop","go",
]

# ============================================================================
# Volumes path normalization (Windows-safe)
# ============================================================================
def to_volume_posix(p: str) -> str:
    """
    Normalize any incoming path to a POSIX UC Volume path:
      - Convert backslashes to forward slashes
      - Strip 'dbfs:/' scheme (Files API expects /Volumes/...)
      - Collapse duplicate slashes
      - Ensure the path begins with '/Volumes/...'
    """
    if p is None:
        raise ValueError("Volume path is None")

    p = str(p).replace("\\", "/")
    if p.startswith("dbfs:/"):
        p = p.replace("dbfs:/", "/")

    parts = [seg for seg in p.split("/") if seg]
    p = "/" + "/".join(parts)

    if not p.startswith("/Volumes/"):
        raise ValueError(f"Volume path must start with /Volumes/. Got: {p}")

    return p

# ============================================================================
# Databricks Authentication
# ============================================================================
def get_oauth_token(host: str, client_id: str, client_secret: str) -> str:
    token_url = f"{host.rstrip('/')}/oidc/v1/token"
    r = requests.post(
        token_url,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": "all-apis",
        },
    )
    r.raise_for_status()
    return r.json()["access_token"]

# ============================================================================
# Databricks Files API (directories & files)
#   - Accept 200 or 204 as success
# ============================================================================
def dbx_mkdirs(host: str, token: str, dir_path: str) -> None:
    dir_path = to_volume_posix(dir_path)
    url = f"{host.rstrip('/')}/api/2.0/fs/directories{dir_path}"
    r = requests.put(url, headers={"Authorization": f"Bearer {token}"})
    if r.status_code not in (200, 201, 204):
        raise RuntimeError(f"[ERROR] mkdirs failed {r.status_code}: {r.text}")

def dbx_put_file(host: str, token: str, file_bytes: bytes, volume_path: str) -> bool:
    volume_path = to_volume_posix(volume_path)
    url = f"{host.rstrip('/')}/api/2.0/fs/files{volume_path}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/octet-stream",
    }
    r = requests.put(url, headers=headers, data=file_bytes, params={"overwrite": "true"})
    if r.status_code not in (200, 204):
        print(f"[ERROR] Files API returned {r.status_code}: {r.text}")
        return False
    return True

def dbx_head_file(host: str, token: str, file_path: str) -> int:
    file_path = to_volume_posix(file_path)
    url = f"{host.rstrip('/')}/api/2.0/fs/files{file_path}"
    r = requests.head(url, headers={"Authorization": f"Bearer {token}"})
    if r.status_code == 200:
        try:
            return int(r.headers.get("Content-Length", "-1"))
        except Exception:
            return -1
    return -1

# ============================================================================
# Audio helpers  (1s/16k/-6 dBFS + gentle augmentation)
# ============================================================================
def to_target_sr_1s(y: np.ndarray, sr_src: int, sr_tgt: int, dur_ms: int) -> np.ndarray:
    if sr_src != sr_tgt:
        g = np.gcd(sr_src, sr_tgt)
        y = resample_poly(y, sr_tgt // g, sr_src // g).astype(np.float32)

    n_tgt = int(sr_tgt * dur_ms / 1000.0)
    if len(y) < n_tgt:
        y = np.pad(y, (0, n_tgt - len(y)))
    elif len(y) > n_tgt:
        start = (len(y) - n_tgt) // 2
        y = y[start:start + n_tgt]

    peak = float(np.max(np.abs(y)) + 1e-12)
    y = (y / peak) * (10 ** (-6 / 20.0))
    return np.clip(y, -1.0, 1.0).astype(np.float32)

def wav_bytes_from_float32(y: np.ndarray, sr: int) -> bytes:
    bio = io.BytesIO()
    sf.write(bio, y, sr, format="WAV", subtype="PCM_16")
    return bio.getvalue()

# Gentler augmentation: closer to GSC public dataset
def speed_perturb(y: np.ndarray, factor: float) -> np.ndarray:
    n_new = max(8, int(len(y) / factor))
    return resample(y, n_new).astype(np.float32)

def schroeder_ir(sr: int, rt60: float = 0.18) -> np.ndarray:
    n = max(64, int(sr * rt60))
    ir = np.zeros(n, dtype=np.float32)
    delays = np.random.randint(sr // 250, sr // 60, size=4)  # smaller, fewer reflections
    gains  = np.random.uniform(0.15, 0.45, size=4)
    for d, g in zip(delays, gains):
        if d < n:
            ir[d] += g
    decay = np.exp(-np.linspace(0, rt60, n) * 6.0).astype(np.float32)
    ir *= decay
    ir[0] += 1.0
    ir /= (np.max(np.abs(ir)) + 1e-12)
    return ir

def add_noise(y: np.ndarray, snr_db: float) -> np.ndarray:
    n = np.random.randn(len(y)).astype(np.float32)
    n = n / (np.max(np.abs(n)) + 1e-12)
    n *= 10 ** ((-6 - snr_db) / 20.0)  # gentler noise (higher SNR)
    return np.clip(y + n, -1, 1).astype(np.float32)

def augment_gentle(y: np.ndarray, sr: int) -> np.ndarray:
    # 50% chance slight speed (0.95–1.05)
    if random.random() < 0.5:
        y = speed_perturb(y, random.uniform(0.95, 1.05))
    # 30% chance light reverb (rt60 ~ 0.12–0.3s)
    if random.random() < 0.3:
        ir = schroeder_ir(sr, rt60=random.uniform(0.12, 0.30))
        y  = fftconvolve(y, ir, mode="full")[:len(y)].astype(np.float32)
    # 40% chance background noise (SNR 22–35 dB)
    if random.random() < 0.4:
        y = add_noise(y, snr_db=random.uniform(22, 35))
    return y

# ============================================================================
# gTTS speech synthesis (real voice, needs internet)
# ============================================================================
def gtts_word_to_array(word: str, sr_tgt: int, dur_ms: int) -> np.ndarray:
    if not GTTS_AVAILABLE:
        raise RuntimeError("gTTS/pydub not installed. Run: pip install gTTS pydub (and sudo apt install -y ffmpeg)")

    tmp_mp3 = Path(tempfile.gettempdir()) / f"tts_{uuid.uuid4().hex[:8]}.mp3"
    tmp_wav = Path(tempfile.gettempdir()) / f"tts_{uuid.uuid4().hex[:8]}.wav"
    try:
        # Generate MP3 with gTTS
        gTTS(text=word, lang='en').save(str(tmp_mp3))

        # Convert MP3 -> WAV (mono) via ffmpeg
        # Python 3.13 compatibility: avoid pydub/audioop
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(tmp_mp3), "-ac", "1", "-ar", str(sr_tgt), str(tmp_wav)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True
        )

        # Load WAV
        y, sr0 = sf.read(str(tmp_wav))
        if y.ndim > 1:
            y = y.mean(axis=1)
        y = y.astype(np.float32)
    finally:
        try: tmp_mp3.unlink(missing_ok=True)
        except Exception: pass
        try: tmp_wav.unlink(missing_ok=True)
        except Exception: pass

    # Standardize -> gentle augment -> standardize
    y = to_target_sr_1s(y, int(sr0), sr_tgt, dur_ms)
    y = augment_gentle(y, sr_tgt)
    y = to_target_sr_1s(y, sr_tgt, sr_tgt, dur_ms)
    return y

# ============================================================================
# Device identity & pool (no "Vol")
# ============================================================================
DEVICE_MODELS = ["EFR32MG24", "EFR32BG24", "EFR32MG21", "EFR32BG22"]

def make_device_identity() -> tuple[str, str]:
    model = random.choice(DEVICE_MODELS)
    tail  = uuid.uuid4().hex[:4].upper()
    device_id = f"SiLabs-{model}-{tail}"
    device_name = f"SiLabs {model} DevKit ({tail})"
    return device_id, device_name

def make_device_pool(n: int) -> list[dict]:
    pool = []
    for _ in range(max(1, n)):
        did, dname = make_device_identity()
        pool.append({"device_id": did, "device_name": dname})
    return pool

# ============================================================================
# ZeroBus event (schema-aligned)
# ============================================================================
def make_event(device_id: str, device_name: str, fname: str, file_path: str, label: str) -> dict:
    return {
        "device_id":   device_id,
        "device_name": device_name,
        "file_name":   fname,
        "file_path":   file_path,
        "class_label": label,
        "content_type": "audio/wav",
        "sample_rate": SAMPLE_RATE,
        "duration_ms": DURATION_MS,
        "ingest_ts":   int(time.time() * 1_000_000),  # microseconds
    }

# ============================================================================
# CLI
# ============================================================================
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="SiLabs Volume + Delta Metadata Simulator (spoken GSC words, multi-device)")
    p.add_argument("--device-pool-size", type=int, default=5, help="Number of devices to simulate")
    p.add_argument("--interval-sec", type=float, default=1.0)
    p.add_argument("--volume-path", default=os.getenv("DATABRICKS_VOLUME_PATH"),
                   help="UC Volume base path, e.g., /Volumes/<catalog>/<schema>/<volume>")
    p.add_argument("--count", type=int, default=None, help="Generate N total samples then exit")
    p.add_argument("--store-bytes", action="store_true", help="Attach audio_bytes to Delta row")
    # Keep these for compatibility, but we will ignore them and always use gTTS
    p.add_argument("--synth-mode", choices=["auto", "tts", "tone","gTTS"], default="auto",
                   help="(ignored on Pi) gTTS is always used for real speech")
    p.add_argument("--labels", default=",".join(DEFAULT_LABELS),
                   help="Comma-separated label set")
    return p.parse_args()

# ============================================================================
# MAIN
# ============================================================================
def main():
    args = parse_args()

    # Validate & normalize volume base
    if not args.volume_path:
        raise SystemExit(
            "ERROR: No --volume-path and DATABRICKS_VOLUME_PATH not set.\n"
            "Example:\n"
            "  DATABRICKS_VOLUME_PATH=/Volumes/<catalog>/<schema>/<volume>\n"
            "  python simulate_volume_ingestion.py --count 1"
        )
    volume_base = to_volume_posix(args.volume_path)

    # Databricks Files API token
    workspace_url = os.getenv("ZEROBUS_WORKSPACE_URL")  # e.g., https://adb-...azuredatabricks.net
    client_id     = os.getenv("ZEROBUS_CLIENT_ID")
    client_secret = os.getenv("ZEROBUS_CLIENT_SECRET")
    if not (workspace_url and client_id and client_secret):
        raise SystemExit("ERROR: Missing ZEROBUS_WORKSPACE_URL / ZEROBUS_CLIENT_ID / ZEROBUS_CLIENT_SECRET.")

    try:
        token = get_oauth_token(workspace_url, client_id, client_secret)
        print("[OK] Authenticated with Databricks Files API.")
    except Exception as e:
        raise SystemExit(f"ERROR: OAuth token fetch failed: {e}")

    # ZeroBus configure (optional; no defaults for table name here)
    if ZEROBUS_AVAILABLE:
        try:
            server_endpoint = os.getenv("ZEROBUS_SERVER_ENDPOINT")  # may be bare host (no scheme)
            table_name      = os.getenv("ZEROBUS_TABLE_NAME")       # MUST come from env or your CLI's data.config
            if not (server_endpoint and table_name):
                raise RuntimeError("Missing ZEROBUS_SERVER_ENDPOINT or ZEROBUS_TABLE_NAME. "
                                   "Provide via env or call your CLI's data.config() before running.")
            zerobus_data.config(
                server_endpoint=server_endpoint,
                workspace_url=workspace_url,
                table_name=table_name,
                client_id=client_id,
                client_secret=client_secret,
            )
            print(f"[OK] ZeroBus configured.")
        except Exception as e:
            print(f"[warn] ZeroBus config failed: {e}")

    # Labels (your original mapping later will keep only on/off as known)
    labels = [s.strip() for s in args.labels.split(",") if s.strip()]

    # Device pool
    devices = make_device_pool(args.device_pool_size)

    print(f"\n[sim] Devices     : {len(devices)}")
    print(f"[sim] Volume Path: {volume_base}")
    print(f"[sim] Synth mode : gTTS (real speech; internet required)")
    print(f"[sim] Labels     : {labels}\n")

    sent = 0
    both_ok = 0

    try:
        while True:
            label = random.choice(labels)
            dev   = random.choice(devices)   # pick a device for this sample

            # 1) Generate audio (real speech via gTTS)
            try:
                y = gtts_word_to_array(label, sr_tgt=SAMPLE_RATE, dur_ms=DURATION_MS)
            except Exception as e:
                print(f"[warn] gTTS failed for '{label}': {e}. Skipping.")
                time.sleep(args.interval_sec)
                continue

            # 2) Encode to WAV bytes
            wav_bytes = wav_bytes_from_float32(y, SAMPLE_RATE)

            # 3) Build destination and ensure directory exists
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")

            # Keep your original mapping: only 'on'/'off' are known, else 'unknown'
            metadata_label = label if label in ["on", "off"] else "unknown"

            fname = f"{metadata_label}_{ts}.wav"
            volume_dest = to_volume_posix(f"{volume_base.rstrip('/')}/{fname}")
            parent_dir  = to_volume_posix(str(Path(volume_dest).parent))

            dbx_mkdirs(workspace_url, token, parent_dir)
            upload_ok = dbx_put_file(workspace_url, token, wav_bytes, volume_dest)

            # 4) Ingest metadata (schema aligned) for the chosen device
            event = make_event(dev["device_id"], dev["device_name"], fname, volume_dest, metadata_label)
            if args.store_bytes:
                event["audio_bytes"] = base64.b64encode(wav_bytes).decode("utf-8")

            meta_ok = False
            if ZEROBUS_AVAILABLE:
                try:
                    meta_ok = bool(zerobus_data.ingest([event]))
                except Exception as e:
                    print(f"[ERROR] Metadata ingest failed: {e}")

            if upload_ok and meta_ok:
                both_ok += 1

            # per-record log (keep concise)
            print(f"[{datetime.now().strftime('%H:%M:%S')}] "
                  f"{'ok' if (upload_ok and meta_ok) else 'partial/failed'} | "
                  f"{dev['device_id']} | {metadata_label:8s} ({label:7s}) | {fname}")

            sent += 1
            if args.count and sent >= args.count:
                break

            time.sleep(args.interval_sec)

    except KeyboardInterrupt:
        print("\n[sim] Stopped by user.")

    # Final single-line result
    print(f"Total records sent: {both_ok}")

if __name__ == "__main__":
    main()
